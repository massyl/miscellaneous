
# Kafka #

![][9]

---
title: Kafka
author: Massyl Nait Mouloud
date: October 27, 2016
output: kafka-presentation

---

# Introducing Kafka #

 - Kafka is a distributed, partitioned, replicated commit log service. 
 - Provides the functionality of a messaging system, but with a unique design. 
 - High throughput distributed messaging system
 - Created at LinkedIn and open sourced in 2011
 - Implemented in Scala and Java

# Motivation of creating Kafka #

  - Unified platform for handling all real-time event feeds
  - High throughput in order to support high volume event feeds
    - LinkedIn handles about 200 billion events/day via Kafka
  - Real-time processing of these Events
  - Low-latency delivery to offer traditional like messaging use cases
  - Fault tolerance when machines fail.

# Kind of application #

  - Metrics 
  - Tracking user activity
  - Buffering (Queuing) for back-pressure support

# Known Customers using Kafka #

  - LinkedIn : Activity streams, metrics, data bus) 
  - Netflix  : Real-time monitoring, event processing
  - Twitter  : Real-time data pipelines (Storm)
  - Spotify  : Log delivery
  - Loggly   : Log collection and processing
  - Mozilla, Airbnb, Cisco, Uber, Square ...

# Kafka is very Fast #

- Fast writes : Sequential writes to disk (Os page cache)
- Fast reads  : From page cache to network socket
- Linux sendfile()(avoid copying data to user space)

# Kafka and other applications #

 - Kafka + Storm
 - Kafka + Custom mutli-threaded apps
 - Kafka + Spark Streaming
 - Kafka + Samza
 - Kafka + Gobblin (Hadoop ingestion)

# Kafka core concepts #

![producer-consumer][1]

# Topics #
 
 - Kafka maintains feeds of messages in categories called topics. 
 - Topics are split into partitions which are replicated


![Topic with 3 partitions][2]

# Partitions #

 - Kafka partitions incoming messages for a topic
 - Ordered and immutable sequence of messages with append only semantic
 - Partitions are assigned to the available Kafka brokers. 
 - The number of partitions is configurable per-topic and per-broker
 - Messages are stored in the order they arrive (Total ordering per partition)
 - Messages are delivered in order they are stored (arrived).
 - Unit of parallelism (see Consumer Group)
  
# Replicas #

 - Backups of a partition
 - Partitions are replicated to make the cluster more resilient against failures.
 - Partition have a configurable replication factor (specified at topic creation time)
 - Each committed message will not be lost as long as the is at least one replica
 - Never read of write to directly
 - (NumberOfReplica - 1) failed brokers before loosing data
 
# Topic vs Partition vs Replica #

![Relationship between topics, partions, and replicas][3]

# Producers #
 
 - Processes that publish messages to a Kafka topic. 
 - Can run in `sync` or `async` mode
 - `sync` blocking operation
 - `sync` configurable (wait only the leader to commit)
 - `asyn` not blocking operation (batch mode)
 - Same Api for `sync` and `async` 
  - Async wraps sync producer
 - Sends each message to particular partition
   - Partition selection based on 
     1. Semantic `key` 
     2. Load balancing `round robin` : 
       - Switches partition each 10 minutes (configurable : topic.metadata.refresh.interval.ms)
 
 - Uses bootsrapping to discover leaders (brokers use Zookeeper under the hood)
 

# Consumers and Consumer Group #

 - Processes that subscribe to topics and process the feed of published messages.
 - Reads only committed messages
 - Uses pull method there is no push
  - Consumers control their consumption speed
 - Uses offsets to read from partitions
 
 ![Consumer group][6]

# Offsets #

 - Sequential unique id of a message inside a partition
 - Consumer track their offsets (per partion and per topic)
 - Consumer uses special `Kafka` topic to track their offsets or Zookeeper (older consumers)
 
![Topic][5]

# Brokers #

 - Kafka is run as a cluster comprised of one or more servers each of which is called a broker. 
 - Leaders of some partitions and follower for others.
 - Can create topics automatically (auto.create.topics.enable, num.partitions and default.replication.factor)
 
# Kafka cluster overview #

- Topic named `zerg.hydra` with 3 partitions and 2 replicas per partition

![Kafka cluster overview][4]

# Zookeeper #

- Used by Brokers to keep track of cluster state information, leader election ...

# Demo #

#### Create topic ####

``` bash

- bin/kafka-topics.sh --zookeeper localhost:2181 --create --topic zerg.hydra --partitions 3 --replication-factor 2
- bin/kafka-topics.sh --zookeeper localhost:2181 --list
- bin/kafka-topics.sh --zookeeper localhost:2181 --describe --topic zerg.hydra

```

#### File System ####

- Directory structure

``` bash
 - tree path/to/log/dir

```

#### Producing messages ####

``` bash
- bin/kafka-console-producer.sh --broker-list localhost:9092,localhost:9093,localhost:9094 --sync --topic zerg.hydra

```

#### Consuming messages ####

``` bash
- bin/kafka-console-consumer.sh --zookeeper localhost:2181 --topic zerg.hydra --from-beginning

```

# Architecture Summary #
 
 - Kafka runs as a Cluster of 1 to n nodes called `Brokers`
 - Each broker have a unique id
 - Brokers use `Zookeeper` to track cluster state information, leader election ...
 - Producers send messages to partitioned topics.
 - Consumers read message from topics using tracked offsets
 
# Hardware specification #

# Kafka #

 - Machines must be dedicated to Kafka only
 - Each Broker on it's machine
 - Multi-core CPUs are valuable
 - Much memory (24GB to 64GB)
  - 4 to 8 GB for kafka broker
  - Remaining memory dedicated to page cache
  - Page cache is what rely helps to get kafka running fast
 - High performance disks is very important also
   - Better to have multiple disks
   - Larger disks allow to store and retain messages for long time

# Zookeeper #

  - Machines must be dedicated to Zookeeper only
  - Must be deployed in Quarum (3 , 5, 8 ...)
  - 1 Zookeeper per machine
  
  
For more details please refer to [kafka machine][7] 

# Administrating Kafka cluster #

# Adding Nodes #

  - Adding more brokers is easy.
  - Partition assignment to new brokers are manul

# Adding new topics and reconfigure existing #
   
  - Very easy to create new topics, just run provided scripts
  - Increase number of partitions for a given topic
  
# Monitoring #

  - https://cwiki.apache.org/confluence/display/KAFKA/System+Tools
  - https://kafka.apache.org/documentation.html#monitoring (JMX: JConsole, VisualVM...)
  - https://cwiki.apache.org/confluence/display/KAFKA/Replication+tools
  - Use Logstash/Kibana

# Brokers #

 - Check if the cluster is operating with all brokers (no down)
 - Check number of replications and adjust replication factor if necessary
 - Data size on disk 
   - must be well balanced across disks and brokers
   - There is a script to balance data/partitions cross brokers
 - Partitions must be well balanced (evenly) cross brokers
 - Leader partition count per broker 
   - Must be balanced across brokers to avoid over loaded brokers
 - Network between brokers must be very fast to allow fast replication
 - num.io.threads should be >= number of disks (start with == #disks)
 - num.network.threads must be adjusted based on number of concurrent producers/consumers
   and replication factor
   
 
# JVM tuning #
   
   - Garbage collection bottleneck
   - Minimize GC pause times (avoid Frequent Full GC)
   - Use G1 (Garbage-first)
   
# Monitoring consumers #

 Problems are almost due to `Consumer lag` and `Rebalancing`
 
 ![Consumer Lag][8]
   
# Kafka Security #

 - Must run behind SSL/TLS
 - For sensible data, use encryption

# Developing Kafka apps #

 - Messages are sent and read from leaders

# Producing messages #
 
 - `sync` 
  - Blocking mod

 - `async` 
  
  - Non blocking mode (sends message in backgroound)
  - High throughput
  - May lose messages if the underlying buffer is full
    1. Number of messages to send <= Speed of the producer
    2. May need more brokers to support the load
    3. For the producer to block indefinitly when full (queue.enqueue.timeout.ms = -1)
    4. Increase queue buffering size (queue.buffering.max.messages)

``` java
  
  Properties props = new Properties();
  props.put("producer.type", "asyn");
  ProducerConfig conf = new ProducerConfig(props);
  Producer producer = new Producer(conf);
  producer.send(KeyedMessage);
```

# Important properties #

|Property | Description|
|---------|------------|
|**client.id**| producer id used in logging for example|
|**producer.type**| async or sync|
|**acks**| number of acks before messages committed|
|**key[value].serializer.class**|configure message serialization|
|**bootsrap.servers**| bootsrapping list of brokers|

# Acknowledgment semantic #

Number of brokers that must `ack` a message before considering it as committed is
Allows to wait between speed (latency) vs durability (message never lost)

 -** if set to 0**
  
   - Fire and forget mode. The producer don't wait for any acknowledgment
   - Messages are sent directly, put in a socket and considered sent
   - Lowest latency and weakest durability
 
 -** if set to 1 **
   - The leader commits the message and acks it without waiting for followers
   - The message can be lost if the leader fails just after sending the ack
   - Good compromise between latency vs durability
   
 -** if set to `all` (-1) **
   - The leader will wait for all in-sync followers to replicate the message before acknowledgment
   - Messages will not be lost if at least one in-sync replica remains alive
   - Best durability but higher latency (waits all ISR to replicate)

# Important aspect to keep in mind #

- `Kafka` performance :

- Message acknowledgment
  - Followers acknowledgment timeout
    - request.timeout.ms 
      If followers don't ack before this timeout, error thrown event messages are committed
 
  - Batching messages
   - Risk to loose messages if producer fails before sending them
   - In `sync` mode blocks till all messages are sent
   - In `async` mode don't block all messages are sent in backgroound
   

# Consuming messages #

 - Pulls messages from brokers
 - Track their offset position
 - 2 Consumer APIs 
  - High level (automatic offset management)
  - Simple consumer (allows more control but offset management is manual)

# Important properties #

|property | description|
|---------|------------|
|group.id |consumer group id(name)|
|zookeeper.connect| to discover brokers, topics (older)|
|fetch.message.max.bytes|number of bytes to fetch for each partition|


# Important aspect to keep in mind #

 - Consumer group (to avoid message duplication)
 - number of consumers in a group == number of partition
 - Message delivered to one consumer per consumer group
 - Messages are received in the order they are stored on Brokers(per partition)
 - No ordering guarantee between partitions
 - If total ordering required for a topic use one partition
 - Adding more consumers causes kafka to rebalance partition assignment
 
# Testing #
 
 - Unit testing with JUnit/TestNG
 - Integration testing with in-memory kafka and Zookeeper
 - Refer to kafka source code there is much test examples
 - https://github.com/miguno/wirbelsturm
 
# Message serialization #
  
  - Can use any message format that fits your need (Json, Xml, Avro,Pprotobuf...)
  - Brokers store the message payload as is

# Thank you #

[1]: file:////home/massyl/softs/java/geodis-eservice/specs/training/producer_consumer.png
[2]: file:////home/massyl/softs/java/geodis-eservice/specs/training/topic.png
[3]: file:////home/massyl/softs/java/geodis-eservice/specs/training/kafka-topics-partitions-replicas.png
[4]: file:////home/massyl/softs/java/geodis-eservice/specs/training/kafka-cluster-overview.png
[5]: file:////home/massyl/softs/java/geodis-eservice/specs/training/consumer-offsets.png
[6]: file:////home/massyl/softs/java/geodis-eservice/specs/training/consumer-group.png
[7]: file:////home/massyl/softs/java/geodis-eservice/specs/training/kafka-machines.md
[8]: file:////home/massyl/softs/java/geodis-eservice/specs/training/consumer-lag.jpg
[9]: file:////home/massyl/softs/java/geodis-eservice/specs/training/kafka-logo.png
