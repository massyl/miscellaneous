
# Apache Kafka #

![][9]
[^1]

---
title: Kafka Ecosystem
author: Massyl NAIT MOULOUD
date: December 06, 2022
output: kafka-presentation

---

# Introducing Kafka #

- Is a streaming platform ecosystem
- Distributed, partitioned and replicated commit log
- Created at LinkedIn and open sourced in 2011
- High throughput and Low-latency
- Fault tolerance when machines fail.
- Implemented in Scala and Java
- Offers `exactly once processing`
[^1]

# Kafka is very Fast #

- Fast writes : Sequential writes to disk
- Fast reads  : From page cache to network socket
- Linux zero copy `sendfile()` from kernel space
[^1]

# Known Customers using Kafka #

- **Paypal**: Fraud detection, user behavior, risk & compliance
- **Goldman** Sachs,JPMorgan, Stripe, Square and Revolut
- **LinkedIn** : Activity streams, metrics, data bus)
- **NYT, Airbnb, Cisco, Uber, Netflix,Twitter and Spotify**

[^1]

# Streaming Frameworks using Kafka #

- Kafka Streams
- Apache Storm
- Apache Spark Streaming
- Apache Samza
- Apache Flink
[^1]

# Kafka core concepts #

![kafka components][1]
[^1]

# Kafka core concepts #

- Producers are decoupled from Consumers
- Fast producer do not affect slow consumers and vice-versa
- Many Consumers do not affect Broker performance
- Producers and Consumers communicate through `Topics`
[^1]

# Topic #

- A streams of related immutable messages(events)
- Is a logical representation
- Used by Producers and Consumers to exchange data
- Producer and Consumer have many-to-many relationship to `Topics`
- Topics are split into partitions which are replicated
[^1]

# Partition #

- Kafka partitions incoming messages for a topic
- Ordered and immutable sequence of messages with append only semantic
- Partitions are assigned to the available Kafka brokers.
- Partitions number is configurable per-topic and per-broker
- Total ordering per partition
- Messages are delivered in order they are stored
- Unit of parallelism (see Consumer Group)
- Configurable retention policy

# Partition #

![Topic with 3 partitions][2]
[^1]

# Topic, Partition and Segments  #

![Topic paritions and segments][10]
[^1]

# Data Retention Policy

- How long to store data(default 7 days)
- You configure globally or per `Topic`
- Business driven (compliance to `GDPR`, audit trails ...)
- Messages are purged by segments
- There is a special treatment for compacted topics
[^1]

# Append only LOG #

- Immutable append only data structure
- Write at the end and read at the head
- Reads do not remove records, thus you can reread them
- Each message in a `Log` is identified by an a unique position
- In Kafka is also called stream of events
- Known as WAL, RedoLog, OpLog, BinOp in databases

[^1]

# Append only LOG #

![Commit Log][18]
[^1]

# Compacted topics #

![Compacted topics][17]
[^1]

# Structure of Records (Events)

![Kafka Producer Record][12]
[^1]

# Replicas #

![Replicas][13]
[^1]

# Replicas #

- Backups of a partition
- Partitions are replicated to make the cluster more resilient against failures.
- Partition have a configurable replication factor (specified at topic creation time)
- Each committed message will not be lost as long as there is at least one replica
- Leader and Follower

[^1]

# Producers #

 - Processes that publish messages to a Kafka topic.
 - **Asyn** not blocking operation (batch mode)
 - Sends each message to particular partition
 - Uses bootsrapping to discover leaders
[^1]

# Producer #

![Kafka Producer][14]
[^1]

# Partioning Strategies

- Round Robing(no key)
- Semantic key partitioning `hash(key) % #partitions`
- Custom partitioner

[^1]

# Consumer #

- Subscribes to one or more topics and pull published messages
- Consumers control their consumption speed
- Uses offsets to keep track of the position in the **Log**
- Must be in **read_committed**

[^1]

# Consumer #

![Kafka Consumer][15]
[^1]

# Consumer Group #

![Consumer group][16]
[^1]

# Consumer Group #

- Failures of consumers in a group trigger `Rebalance`
- Adding more consumers to a group for Scaling out the consumption
- Max parallelism is bound by *#partition*
[^1]

# Offsets #

![Offsets][18]
[^1]

# Offsets #

 - Sequential id of a message inside a partition
 - Consumer track their offsets per partition and per topic
 - Consumer uses special `Kafka` topic to track their offsets

# Message serialization #

- Kafka understands only bytes
- Use any message format that fits your need
- Brokers store the message payload as is
- Prefer **Avro** or **Protobuf**

# Brokers #

 - Kafka is run as a cluster of one or more servers called a broker.
 - Leaders of some partitions and follower for others.
 - There is one special broker named the **Controller**
[^1]

# Brokers #

![Leader and Followers][11]
[^1]

# Acknowledgment semantic #

### Fire and forget (0)

- No wait for acknowledgment
- Lowest latency and weakest durability

### Leader ack (1)

- The leader acks the message
- If the leader fails just after sending the ack, message will be lost
- Good compromise between latency vs durability

### All in Sync (-1)

- The leader wait for all in-sync followers before acknowledgment
- No loss if at least one in-sync replica remains alive
- Best durability but higher latency

[^1]

# Kafka Delivery Guaranties

- At most once
- At least once
- Exactly once

[^1]

# Kafka Streams #

- Added to Kafka ecosystem in 2016
- Is a lightweight java library for stream processing applications
- High-level DSL that looks like Java streams
- Low-level Processor API for fine-grained control
- First class representation of `Streams` and `Tables`
- Used for enriching, transforming real-time streams
- React to event immediately when available

[^1]


# Kafka Streams compared to Producer and Consumer

- A rich set of operators for transforming streams of data
- Local and fault-tolerant state
- Streams and Tables are first class citizens
- More advanced time handling(event, ingest, processing)
- Joins separate streams, tables
- Group and aggregate events into windowed time buckets
- You can build stateless or stateful stream applications
- Builds on Producer, Consumer and Consumer Group
- Exactly once processing semantic

[^1]

# Kafka Streams Processing Model

- Event-at-a-time processing, one at a time, as they come in
- Based on KAPPA Architecture
- Data-flow programming using DAG
- Processor Topology and Sub-Topology
- Stream/Table duality (stream of changes)
- KStream is an abstraction of a partitioned record stream, using insert semantics
- KTable is an abstraction of a partitioned table that uses update semantics
- GlobalKTable Table that contain all data

[^1]

# Kafka Streams

![Kafka Streams][19]

[^1]

# Kafka Connect #

- Used to move data between Kafka and other data-stores
- Scalable and Reliable
- Relies on Producer and Consumer
- Connect uses a protocol like Consumer Group to define cluster
- Workers with same `group.id` are part of the same cluster
- APIs and runtime to develop and run connector plugins
- Runs a cluster of workers that execute Connector code
- Workers read from and write to Kafka

[^1]

# Kafka Connector Plugin #

- Libraries used by Kafka Connect to move data
- Installed on workders, configured and management using Rest Api
- Uses tasks to move large data in parallel
- Source connector read data from external system and hand it to worker
- Sink connector take data from worker and write it to external system
[^1]

# Converter #

- Used to serialization and De-serialization data
- Equivalent to Kafka Serializer/DeSerializer

[^1]

# Transformation

- Simple transformation on the Record
- Remove fields (Sensible data)
- Add meta-data information (data lineage)
- Rename field, topic or change field type
- Select primary key
- Must not be used to implement more advanced transformation
- Advanced and complex transformations use Kafka Streams instead

# Kafka ecosystem big picture #

![Kafka ecosystem][20]
[^1]

# Architecture Summary #

 - Kafka runs as a Cluster of 1 to n nodes called `Brokers`
 - Each broker have a unique id
 - Brokers use `KRaft` to track cluster state information, leader election ...
 - Producers send messages to partitioned topics
 - Consumers read message from topics using tracked offsets

[^1]

# How to choose number of partitions #

- Often Depends on through you need to achieve
- More partitions lead to higher throughput (parallelism)
- Partition `nb >= max(T/P, T/C)`
 - **T**: target throughput to achieve
 - **P**: throughput of production on 1 partition
 - **C**: throughput of consumption on 1 partition
- Single partition can achieve ` >= 10MB/s` for production
- Consumption depends on business use-cases(processing)
- Over partition for 1 to 3 years beforehand

[^1]

# Lots of Partitions impact performance #

- More open file handles (index, segment, tx, tindex)
- May increase unavailability when broker fails abruptly(dirty)
- Controller failure increase unavailability
- If latency is a concern you need less partitions
- Requires more memory on Producer and Consumer

[^1]

# Important aspect to keep in mind #

 - Consumer group
 - number of consumers in a group == number of partition
 - One consumer per partition per consumer group
 - Total ordering per partition
 - No ordering guarantee between partitions
 - If total ordering required for a topic, use one partition
 - Add/Remove consumer causes rebalance
 - Design carefully your schemas
 - Partition correctly and take future target(1 to 3 years)
 - No silver bullet, every solution has **pros** and **cons**

[^1]

# Thank you #

**Questions ?**

[^1]

# Bibliography

- Few images are taken from the internet
- This presentation is inspired by `Tim Beglund` from Confluent
- You can find more learning videos from `Confluent`

[^1]


[1]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_components.png
[2]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_topic.png
[3]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_topic.png
[4]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka-cluster-overview.png
[5]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/consumer-offsets.png
[6]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/consumer-group.png
[7]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka-machines.md
[8]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/consumer-lag.jpg
[9]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_logo.png
[10]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_topic_partition_segments.png
[11]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_topic_on_brokers.png
[12]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_records.png
[13]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_broker_replicas.png
[14]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_producer.png
[15]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_consumer.png
[16]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_consumer_group.png
[17]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_compacted_topics.png
[18]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_commit_log.png
[19]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_streams.png
[20]: file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/kafka_connect.png
[^1]: ![](file:////home/massyl/softs/bforbank/keynotes/kafka_ecosystem/bforbank_logo.png){#footer .class  width=30 height=20px margin-left=200}
