let currentAccount = null
let web3
//let abi;
/* let contactAddress = '0xB16bEc01bfe4F13D5e85A2F75F51893D797Df1F7' */
let contactAddress = '0x0f2C48843fd25e5cf2cbC35e18ce9902b0805E44'
let to = '0xB19bba3CfA79c0b0a29C11A13846E4b08c204364'
let abi = human_standard_token_abi

function handleAccountsChanged(accounts) {
  console.log('Calling HandleChanged')
  if (accounts.length === 0) {
    console.log('Please connect to MetaMask.')
    /* $('#ask_for_metamas').html('content.html') */
    $('#enableMetamask').html('Connect with Metamask')
  } else if (accounts[0] !== currentAccount) {
    currentAccount = accounts[0]
    /*          $('#enableMetamask').html(currentAccount) */
    $('#status').html('')
    /* if(currentAccount != null) {
           // Set the button label
            $('#enableMetamask').html(currentAccount)
         } */
  }
  console.log('WalletAddress in HandleAccountChanged =' + currentAccount)
}

function connect() {
  console.log('Calling connect()')
  ethereum
    .request({ method: 'eth_requestAccounts' })
    .then(handleAccountsChanged)
    .catch((err) => {
      if (err.code === 4001) {
        // EIP-1193 userRejectedRequest error
        // If this happens, the user rejected the connection request.
        console.log('Please connect to MetaMask.')
        $('#status').html('You refused to connect Metamask')
      } else {
        console.error(err)
      }
    })
}

function detectMetaMask() {
  if (typeof window.ethereum !== 'undefined') {
    return true
  } else {
    return false
  }
}

async function getValue() {
  let currentAccount = '0xb0287DdA36d161B46cd2938Afe592a9254bd18dc'
  console.log('GetValue')
  const contractFirst = new web3js.eth.Contract(abi, contactAddress)
  contractFirst.methods
    .balanceOf(currentAccount)
    .call()
    .then(function (result) {
      $('#getValue').html(web3js.utils.fromWei(result))
    })
}

async function payWithPoken(onSuccess, onFailure) {
  let currentAccount = '0xb0287DdA36d161B46cd2938Afe592a9254bd18dc'
  input_value = web3js.utils.toWei('1')
  const contractFirst = new web3js.eth.Contract(abi, contactAddress)
  web3js.eth.defaultAccount = window.ethereum.defaultAccount
  contractFirst.methods
    .transfer(to, input_value)
    .send({ from: currentAccount })
    .on('transactionHash', (hash) => {
      onSuccess(hash)
    })
    .on('receipt', (receipt) => {
      console.log(receipt)
    })
    .catch((e) => {
      onFailure(e)
    })
}
