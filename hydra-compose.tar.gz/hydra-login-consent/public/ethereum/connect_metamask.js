$(document).ready(function () {
  m = detectMetaMask()
  if (m) {
    $('#metaicon').removeClass('meta-gray')
    $('#metaicon').addClass('meta-normal')
    /*         $('#enableMetamask').attr('disabled', false) */
    connect() // Make sure the connected wallet is being returned
  } else {
    $('#enableMetamask').attr('disabled', true)
    $('#metaicon').removeClass('meta-normal')
    $('#metaicon').addClass('meta-gray')
  }

  try {
    web3js = new Web3(ethereum)
  } catch (error) {
    alert(error)
  }

  $('#setValue').click(function () {
    payWithPoken(
      (hash) => {
        $('#setValue').attr('disabled', true)
        console.log('Got transaction hash : ' + hash)
        $('#consent_form').append(
          "<input type='hidden' name='tx' id='tx' value=" + hash + '/>'
        )
      },
      (err) => {
        console.log('Got tx error : ' + err)
        $('#tx').val('Refused')
      }
    )
  })

  //Fetch Value from Smart Contract
  getValue()
})
