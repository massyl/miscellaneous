import url from 'url'

import express from 'express'
import urljoin from 'url-join'
import csrf from 'csurf'
import { ConsentRequestSession } from '@oryd/hydra-client'
import { v4 as uuidv4 } from 'uuid'
import axios from 'axios'

import { hydraAdmin } from '../config'
import userService from '../model/userService'

import { oidcConformityMaybeFakeSession } from './stub/oidc-cert'

const csrfProtection = csrf({ cookie: true })
const router = express.Router()
const payWithPokenBaseUrl = process.env.PAY_WITH_POKEN_API_BASEURL

router.get('/', csrfProtection, async (req, res, next) => {
  try {
    const queryParams = url.parse(req.url, true).query
    const challenge = String(queryParams.consent_challenge)
    if (!challenge) {
      throw new Error(
        'Expected a consent challenge to be set but received none.'
      )
    }

    const { data: consentData } = await hydraAdmin.getConsentRequest(challenge)

    if (consentData.skip) {
      return hydraAdmin
        .acceptConsentRequest(challenge, {
          grant_scope: consentData.requested_scope,
          grant_access_token_audience:
            consentData.requested_access_token_audience,
          session: {}
        })
        .then(({ data: body }) => {
          res.redirect(String(body.redirect_to))
        })
    }

    const user_info = consentData.subject.split(':')
    const user = await userService.findById(user_info[1])

    if (
      consentData.requested_scope.length === 1 &&
      consentData.requested_scope[0] === 'openid'
    ) {
      const session: ConsentRequestSession = {
        access_token: { id: user.id },
        id_token: { id: user.id }
      }

      const { data: acceptConsentData } = await hydraAdmin.acceptConsentRequest(
        challenge,
        {
          grant_scope: consentData.requested_scope,
          session: oidcConformityMaybeFakeSession(
            consentData.requested_scope,
            consentData,
            session
          ),
          grant_access_token_audience:
            consentData.requested_access_token_audience,
          remember: Boolean(req.body.remember),
          remember_for: 3600
        }
      )
      return res.redirect(String(acceptConsentData.redirect_to))
    }

    const query = url.parse(consentData.request_url, true).query
    const initial_tx_id = String(query.tx_id)
    const initial_amount = String(query.amount)
    const initial_currency = String(query.currency)
    const initial_currency_symbol = String(query.currency_symbol)
    const target_tx_token_symbol = String(query.token_symbol)
    const target_tx_token_address = String(query.token_address)

    const payload = await fetchPrice(
      initial_currency,
      Number(initial_amount),
      target_tx_token_symbol
    )

    if (!payload) throw new Error(`Couldn't fetch pricing`)

    if (user) {
      const user_wallets = []
      user_wallets.push(user.wallet)
      res.render('consent', {
        csrfToken: req.csrfToken(),
        challenge: challenge,
        requested_scope: consentData.requested_scope,
        user: user_info[0],
        user_account: user_wallets,
        client: consentData.client,
        action: urljoin(process.env.BASE_URL || '', '/consent'),
        initial_tx_id: initial_tx_id,
        initial_amount: initial_amount,
        initial_currency: initial_currency,
        initial_currency_symbol: initial_currency_symbol,
        target_tx_amount:
          Math.round(payload.data.amount_converted * 1000) / 1000,
        target_tx_token_symbol: payload.data.amount_currency,
        target_tx_token_address: target_tx_token_address,
        current_pkn_price: Math.round(payload.data.price * 100000) / 100000,
        last_updated: new Date(payload.data.last_updated).toUTCString()
      })
    } else {
      //TODO add global error view and then redirect from here
    }
  } catch (error) {
    next(error)
  }
})

router.post('/', csrfProtection, (req, res, next) => {
  const challenge = req.body.challenge
  if (req.body.submit === 'Deny access') {
    return hydraAdmin
      .rejectConsentRequest(challenge, {
        error: 'access_denied',
        error_description: 'The resource owner denied the request'
      })
      .then(({ data: body }) => {
        res.redirect(String(body.redirect_to))
      })
      .catch(next)
  }
  // label:consent-deny-end
  let grantScope = req.body.grant_scope
  if (!Array.isArray(grantScope)) {
    grantScope = [grantScope]
  }
  const client_metadata = JSON.parse(req.body.client_metadata)
  const user_account = req.body.selected_account
  const session: ConsentRequestSession = {
    access_token: {
      from: user_account,
      to: client_metadata.account,
      initial_amount: req.body.initial_amount,
      initial_currency: req.body.initial_currency,
      initial_tx_id: req.body.initial_tx_id,
      chain_id: req.body.chain_id,
      target_tx_amount: req.body.target_tx_amount,
      target_tx_token_symbol: req.body.target_tx_token_symbol,
      target_tx_token_address: req.body.target_tx_token_address,
      nonce: uuidv4()
    },

    id_token: {}
  }
  hydraAdmin
    .getConsentRequest(challenge)
    .then(({ data: body }) => {
      console.log({
        grant_scope: grantScope,
        session: oidcConformityMaybeFakeSession(grantScope, body, session),
        grant_access_token_audience: body.requested_access_token_audience,
        remember: Boolean(req.body.remember),
        remember_for: 3600
      })
      return hydraAdmin
        .acceptConsentRequest(challenge, {
          grant_scope: grantScope,
          session: oidcConformityMaybeFakeSession(grantScope, body, session),
          grant_access_token_audience: body.requested_access_token_audience,
          remember: Boolean(req.body.remember),
          remember_for: 3600
        })
        .then(({ data: body }) => {
          res.redirect(String(body.redirect_to))
        })
    })
    .catch(next)
  // label:docs-accept-consent
})

async function fetchPrice(
  initial_currency: string,
  initial_amount: number,
  target_tx_token_symbol: string
) {
  try {
    /** POST http://payWithPokenAPI:{port}/payWithPoken/api/v1/token/price
     *  @queryParam {string} initial_currency - fiat currency to convert token amount from
     *  @queryParam {number} initial_amount - amount to convert in token
     *  @queryParam {string} target_tx_token_symbol - symbol of the token to convert into
     *  @returns {price: currentPKNPrice: number, initial_amount: number, initial_currency: string, amount_converted: number, amount_currency: string, last_updated: string}
     */
    return await axios({
      method: 'POST',
      url: payWithPokenBaseUrl + '/token/price',
      params: {
        currency: initial_currency,
        amount: initial_amount,
        'token-symbol': target_tx_token_symbol
      },
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      }
    })
  } catch (error) {
    return null
  }
}

export default router
