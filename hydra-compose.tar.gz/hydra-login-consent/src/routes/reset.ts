import url from 'url'

import express from 'express'
import urljoin from 'url-join'
import csrf from 'csurf'

import userService from '../model/userService'
import tokenService from '../model/tokenService'

const csrfProtection = csrf({ cookie: true })
const router = express.Router()

router.get('/', csrfProtection, async (req, res, next) => {
  try {
    const query = url.parse(req.url, true).query
    const challenge = query.login_challenge || query.challenge
    const resetId = query.resetId

    if (resetId) {
      const token = await tokenService.getOne(resetId)
      const user = token && (await userService.findById(token.user))
      if (!token || !user) {
        return res.render('reset', {
          challenge,
          invalidLink: true,
          title: 'Connect with Pokmi account',
          csrfToken: req.csrfToken(),
          action: urljoin(process.env.BASE_URL || '', '/reset')
        })
      }

      return res.render('reset', {
        challenge,
        resetId,
        email: user.email,
        title: 'Connect with Pokmi account',
        csrfToken: req.csrfToken(),
        action: urljoin(process.env.BASE_URL || '', '/reset')
      })
    }

    res.render('reset', {
      challenge,
      title: 'Connect with Pokmi account',
      csrfToken: req.csrfToken(),
      action: urljoin(process.env.BASE_URL || '', '/reset')
    })
  } catch (error) {
    next(error)
  }
})

router.post('/', csrfProtection, async (req, res) => {
  const { email, password, challenge, resetId } = req.body

  try {
    if (resetId) {
      const token = await tokenService.getOne(resetId)
      const user = token && (await userService.findById(token.user))
      if (token) await tokenService.remove(token.id)
      if (!token || !user) {
        return res.render('reset', {
          challenge,
          invalidLink: true,
          title: 'Connect with Pokmi account',
          csrfToken: req.csrfToken(),
          action: urljoin(process.env.BASE_URL || '', '/reset')
        })
      }

      await userService.updatePassword(user, password)

      return res.render('reset', {
        challenge,
        resetId,
        email: user.email,
        success: true,
        title: 'Connect with Pokmi account',
        csrfToken: req.csrfToken(),
        action: urljoin(process.env.BASE_URL || '', '/reset')
      })
    }

    const user = await userService.findByEmail(email)
    if (user) await tokenService.resetPass(user)

    res.render('reset', {
      challenge,
      success: true,
      csrfToken: req.csrfToken()
    })
  } catch (error) {
    res.render('reset', {
      challenge,
      email,
      resetId,
      title: 'Connect with Pokmi account',
      csrfToken: req.csrfToken(),
      error:
        error.name === 'internal'
          ? error.message
          : 'Something went wrong. Please try again later.',
      action: urljoin(
        process.env.BASE_URL || '',
        `/reset${challenge ? `?challenge=${challenge}` : ''}`
      )
    })
  }
})

export default router
