import url from 'url'

import urljoin from 'url-join'
import csrf from 'csurf'
import express from 'express'

import userService from '../model/userService'

const router = express.Router()

const csrfProtection = csrf({ cookie: true })

router.get('/', csrfProtection, function (req, res, next) {
  try {
    const challenge = url.parse(req.url, true).query.challenge
    const referralId = url.parse(req.url, true).query.referralId
    res.render('register', {
      challenge,
      referralId,
      csrfToken: req.csrfToken(),
      title: 'Pokmi account creation',
      action: urljoin(process.env.BASE_URL || '', '/register')
    })
  } catch (error) {
    next(error)
  }
})

router.post('/', csrfProtection, async (req, res) => {
  const { challenge, email, referralId } = req.body
  try {
    const user = await userService.create(req.body)

    res.render('register', {
      challenge,
      csrfToken: req.csrfToken(),
      title: 'Pokmi account creation',
      email: user.email,
      action: urljoin(
        process.env.BASE_URL || '',
        `/register${challenge ? `?challenge=${challenge}` : ''}`
      ),
      confirmationLink: true
    })
  } catch (error) {
    res.render('register', {
      challenge,
      email,
      referralId,
      title: 'Pokmi account creation',
      csrfToken: req.csrfToken(),
      error:
        error.name === 'internal'
          ? error.message
          : 'Fail to create account. Please try again.',
      action: urljoin(
        process.env.BASE_URL || '',
        `/register${challenge ? `?challenge=${challenge}` : ''}`
      )
    })
  }
})

export default router
