import url from 'url'

import express from 'express'
import urljoin from 'url-join'
import csrf from 'csurf'

import { hydraAdmin } from '../config'
import userService from '../model/userService'
import mfaService from '../model/mfaService'

import { oidcConformityMaybeFakeAcr } from './stub/oidc-cert'

const csrfProtection = csrf({ cookie: true })
const router = express.Router()

router.get('/', csrfProtection, async (req, res, next) => {
  try {
    const query = url.parse(req.url, true).query
    const challenge = query.login_challenge || query.challenge
    if (!challenge) {
      throw new Error('Expected a login challenge to be set but received none.')
    }
    const { data: body } = await hydraAdmin.getLoginRequest(String(challenge))
    if (body.skip) {
      return hydraAdmin
        .acceptLoginRequest(String(challenge), {
          subject: String(body.subject)
        })
        .then(({ data: body }) => {
          res.redirect(String(body.redirect_to))
        })
    }
    res.render('login', {
      challenge,
      title: 'Connect with Pokmi account',
      csrfToken: req.csrfToken(),
      action: urljoin(process.env.BASE_URL || '', '/login')
    })
  } catch (error) {
    next(error)
  }
})

router.post('/', csrfProtection, async (req, res, next) => {
  const { email, password, challenge, token } = req.body
  let needMfa = false
  try {
    if (req.body.submit === 'Deny access') {
      return hydraAdmin
        .rejectLoginRequest(challenge, {
          error: 'access_denied',
          error_description: 'The resource owner denied the request'
        })
        .then(({ data: body }) => {
          res.redirect(String(body.redirect_to))
        })
        .catch(next)
    }

    const user = await userService.authenticate(email, password)
    const mfa = await mfaService.getByUser(user.id)
    if (mfa) {
      needMfa = true
      if (!token) {
        return res.render('login', {
          challenge,
          email,
          password,
          mfa: true,
          title: 'Connect with Pokmi account',
          csrfToken: req.csrfToken(),
          action: urljoin(
            process.env.BASE_URL || '',
            `/login${challenge ? `?challenge=${challenge}` : ''}`
          )
        })
      }
      const isValid = await mfaService.verify(user.id, token)
      if (!isValid) {
        const error = new Error('Fail to log in. Invalid 2FA token')
        error.name = 'internal'
        throw error
      }
    }

    const { data: loginRequest } = await hydraAdmin.getLoginRequest(challenge)
    const { data: acceptLoginData } = await hydraAdmin.acceptLoginRequest(
      challenge,
      {
        subject: user.name + ':' + user.id,
        context: {},
        remember: Boolean(req.body.remember),
        remember_for: 3600,
        acr: oidcConformityMaybeFakeAcr(loginRequest, '0')
      }
    )
    return res.redirect(String(acceptLoginData.redirect_to))
  } catch (error) {
    res.render('login', {
      challenge,
      email,
      password,
      mfa: needMfa,
      title: 'Connect with Pokmi account',
      csrfToken: req.csrfToken(),
      error:
        error.name === 'internal'
          ? error.message
          : 'Fail to log in. Please try again.',
      action: urljoin(
        process.env.BASE_URL || '',
        `/login${challenge ? `?challenge=${challenge}` : ''}`
      )
    })
  }
})

export default router
