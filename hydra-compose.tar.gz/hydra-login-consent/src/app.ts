import path from 'path'

import dotenv from 'dotenv'
import express, { NextFunction, Response, Request } from 'express'
import logger from 'morgan'
import cookieParser from 'cookie-parser'
import bodyParser from 'body-parser'
import cors from 'cors'
import favicon from 'serve-favicon'

import routes from './routes'
import login from './routes/login'
import register from './routes/register'
import reset from './routes/reset'
import consent from './routes/consent'

dotenv.config()

const app = express()

app.set('views', path.join(__dirname, '..', 'views'))
app.set('view engine', 'pug')

const corsOptions = {
  origin: '*',
  credentials: true, //access-control-allow-credentials:true
  methods: ['GET', 'POST'],
  optionSuccessStatus: 200
}
app.use(logger('dev'))
app.use(cors(corsOptions))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(express.static(path.join(__dirname, '..', 'public')))
app.use(favicon(path.join(__dirname, '..', 'public', 'favicon.ico')))

app.use('/', routes)
app.use('/login', login)
app.use('/register', register)
app.use('/reset', reset)
app.use('/consent', consent)

// catch 404 and forward to error handler
app.use((req, res, next) => {
  next(new Error('Not Found'))
})

app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  res.status(500).render('error', {
    message: err.message
  })
})

const listenOn = Number(process.env.PORT || 3000)
app.listen(listenOn, () => {
  console.log(`Listening on http://0.0.0.0:${listenOn}`)
})
