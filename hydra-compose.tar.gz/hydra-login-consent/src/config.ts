import { AdminApi, Configuration } from '@oryd/hydra-client'
import _ from 'lodash'

import configJson from '../config.json'

const commonConfig = configJson.common
const environment = process.env.NODE_ENV || 'dev'
const environmentConfig = configJson[environment]
const dbUrl = process.env.MONGODB_URI || environmentConfig.connectionString
const dbConfig = { connectionString: dbUrl }
const config = _.merge(commonConfig, environmentConfig, dbConfig)

const baseOptions: any = {}

if (process.env.MOCK_TLS_TERMINATION) {
  baseOptions.headers = { 'X-Forwarded-Proto': 'https' }
}

const hydraAdmin = new AdminApi(
  new Configuration({
    basePath:
      process.env.HYDRA_ADMIN_URL || 'http://oauth-client.localhost:4445',
    baseOptions
  })
)

export { hydraAdmin, config }
