import mongoose from 'mongoose'

const Schema = mongoose.Schema

const schema = new Schema(
  {
    id: String,
    user: String,
    enabled: Boolean,
    secret: {
      ascii: String,
      hex: String,
      base32: String,
      otpauth_url: String
    },
    created_at: Date,
    updated_at: Date
  },
  { autoCreate: false, collection: 'mfa' }
)

export default mongoose.model('Mfa', schema)
