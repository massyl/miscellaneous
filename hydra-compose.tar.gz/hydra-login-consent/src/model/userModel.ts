import mongoose from 'mongoose'

const Schema = mongoose.Schema

const schema = new Schema(
  {
    id: String,
    email: String,
    wallet: String,
    password: String,
    email_verified: Boolean,
    has_password: Boolean,
    referrer: String,
    created_at: Date,
    updated_at: Date,
    deleted: Boolean
  },
  { autoCreate: false }
)

export default mongoose.model('User', schema)
