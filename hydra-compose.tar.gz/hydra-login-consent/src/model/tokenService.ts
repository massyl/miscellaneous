﻿import { v4 as uuidv4 } from 'uuid'

import { Token } from '../utils/db'

enum TokenTypes {
  emailVerify = 'emailVerify',
  passwordReset = 'passwordReset',
  walletCreation = 'walletCreation'
}

export default {
  getOne,
  createAccount,
  resetPass,
  remove
}

async function getOne(id) {
  const token = await Token.findOne({ id })
  if (!token) return null

  return token
}

async function createAccount(userId) {
  const token = await Token.create({
    id: uuidv4(),
    user: userId,
    type: TokenTypes.walletCreation,
    created_at: new Date()
  })

  // await this.sendinblueService.send(MailingTypes.walletCreation, {
  //   origin,
  //   user,
  //   magicToken: token.id
  // })

  return token
}

async function resetPass(userId) {
  const token = await Token.create({
    id: uuidv4(),
    user: userId,
    type: TokenTypes.passwordReset,
    created_at: new Date()
  })

  // await this.sendinblueService.send(MailingTypes.passwordReset, {
  //   origin,
  //   user,
  //   magicToken: token.id
  // })

  return token
}

async function remove(id) {
  const token = await getOne(id)

  if (token) await token.remove()
}
