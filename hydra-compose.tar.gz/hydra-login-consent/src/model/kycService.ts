﻿import { Kyc } from '../utils/db'

export default {
  getByUser
}

async function getByUser(userId) {
  const kyc = await Kyc.findOne({
    user: userId
  })
  if (!kyc) return null

  return kyc
}
