import mongoose from 'mongoose'

const Schema = mongoose.Schema

const schema = new Schema(
  {
    id: String,
    user: String,
    type: String,
    created_at: Date
  },
  { autoCreate: false }
)

export default mongoose.model('Token', schema)
