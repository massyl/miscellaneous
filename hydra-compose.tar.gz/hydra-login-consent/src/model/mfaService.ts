﻿import { totp } from 'speakeasy'

import { Mfa } from '../utils/db'

export default {
  getByUser,
  verify
}

async function getByUser(userId) {
  const mfa = await Mfa.findOne({
    user: userId,
    enabled: true
  })
  if (!mfa) return null

  return mfa
}

async function verify(userId, token) {
  const mfa = await getByUser(userId)
  if (!mfa) return null
  if (!mfa.enabled) {
    const error = new Error('You must verify your token first before using it')
    error.name = 'internal'
    throw error
  }

  return totp.verify({
    token: token.toString().replace(/\s/g, ''),
    secret: mfa.secret.base32,
    encoding: 'base32',
    window: 1
  })
}
