﻿import { ObjectID } from 'mongodb'

import { Referral } from '../utils/db'

export default {
  create,
  countByReferrer
}

async function create(referrerId, userId) {
  const id = new ObjectID()
  return Referral.create({
    _id: id,
    id: id.toString(),
    referrer: referrerId,
    user: userId,
    erc: 0,
    bsc: 0,
    active: false,
    created_at: new Date(),
    updated_at: new Date(),
    deleted: false
  })
}

async function countByReferrer(userId) {
  return Referral.count({ referrer: userId, active: true })
}
