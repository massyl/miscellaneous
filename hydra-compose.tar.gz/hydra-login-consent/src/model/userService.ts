﻿import { pbkdf2Sync } from 'crypto'

import { decode } from 'url-safe-base64'
import { ObjectID } from 'mongodb'
import env from 'env-var'

import { User } from '../utils/db'

import tokenService from './tokenService'
import referralService from './referralService'
import kycService from './kycService'

export default {
  authenticate,
  findById,
  findByEmail,
  create,
  updatePassword
}

const passwordSalt =
  env.get('PASSWORD_SALT ').asString() ?? 'D2sProY5Tghaxy8FkDEhWAehVVRxoBVW'
const passwordAlg = 'SHA256'
const passwordIterations = 100000
const passwordByteLength = 128
const MAX_REFERRAL = 500

export const hashPassword = (email: string, password: string): string => {
  const salt = `${email.toLowerCase()}_${passwordSalt}`
  return pbkdf2Sync(
    password,
    salt,
    passwordIterations,
    passwordByteLength,
    passwordAlg
  ).toString('hex')
}

async function updatePassword(user, password) {
  if (!user.email) {
    const error = new Error('User must have an email.')
    error.name = 'internal'
    throw error
  }
  if (password.length > 127 || password.length < 8) {
    const error = new Error(
      'Password length must be between 8 and 127 characters.'
    )
    error.name = 'internal'
    throw error
  }
  const hashed = hashPassword(user.email, password)
  await User.findOneAndUpdate(
    { id: user.id },
    {
      password: hashed,
      has_password: true,
      email_verified: true,
      updated_at: new Date()
    }
  )
}

async function authenticate(email: string, pwd: string) {
  const hashed = hashPassword(email, pwd)
  const user = await User.findOne({
    password: hashed,
    email: email.toLowerCase(),
    deleted: { $ne: true }
  })
  if (!user) {
    const error = new Error('Fail to log in. Invalid email or password.')
    error.name = 'internal'
    throw error
  }

  return user
}

async function findById(id: string) {
  const user = await User.findOne({
    id: id,
    deleted: { $ne: true }
  })

  if (!user) return null

  return user
}

async function findByEmail(email: string) {
  const user = await User.findOne({ email })

  if (!user) return null

  return user
}

async function create(userParams) {
  const { email, referralId } = userParams
  const userFound = await findByEmail(email)
  if (userFound) {
    const error = new Error('A Pokmi account already exists for this email')
    error.name = 'internal'
    throw error
  }

  const referrer = await getReferrer(referralId)

  const id = new ObjectID()
  const createdUser = await User.create({
    _id: id,
    id: id.toString(),
    email: email.toLowerCase(),
    wallet: '',
    email_verified: false,
    has_password: false,
    referrer: referrer?.id || '',
    created_at: new Date(),
    updated_at: new Date(),
    deleted: false
  })

  if (referrer) {
    await referralService.create(referrer.id, createdUser.id)
  }

  await tokenService.createAccount(createdUser.id)

  return createdUser
}

async function getReferrer(referralId) {
  if (!referralId) return null

  const referrer = await findById(
    Buffer.from(decode(referralId), 'base64').toString('hex')
  )
  if (!referrer) {
    const error = new Error('Your Referral ID is invalid')
    error.name = 'internal'
    throw error
  }

  const kyc = await kycService.getByUser(referrer.id)
  if (!kyc || kyc.status !== 'approved') {
    const error = new Error('Your referrer is not yet a valid creator')
    error.name = 'internal'
    throw error
  }

  const referrals = await referralService.countByReferrer(referrer.id)
  console.log('userService.ts:116 referrals:', referrals)
  if (referrals > MAX_REFERRAL) {
    const error = new Error(
      `Your referrer have reached the maximum number of referrals (${MAX_REFERRAL})`
    )
    error.name = 'internal'
    throw error
  }

  return referrer
}
