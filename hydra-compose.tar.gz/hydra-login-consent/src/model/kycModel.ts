import mongoose from 'mongoose'

const Schema = mongoose.Schema

const schema = new Schema(
  {
    id: String,
    applicationId: String,
    user: String,
    status: String,
    created_at: Date,
    updated_at: Date
  },
  { autoCreate: false, collection: 'kyc' }
)

export default mongoose.model('Kyc', schema)
