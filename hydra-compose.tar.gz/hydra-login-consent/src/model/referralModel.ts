import mongoose from 'mongoose'

const Schema = mongoose.Schema

const schema = new Schema(
  {
    id: String,
    referrer: String,
    user: String,
    active: Boolean,
    created_at: Date,
    updated_at: Date,
    deleted: Boolean
  },
  { autoCreate: false }
)

export default mongoose.model('Referral', schema)
