import mongoose from 'mongoose'

import { config } from '../config'
import userModel from '../model/userModel'
import tokenModel from '../model/tokenModel'
import referralModel from '../model/referralModel'
import kycModel from '../model/kycModel'
import mfaModel from '../model/mfaModel'

mongoose.connect(config.connectionString)
mongoose.Promise = global.Promise

export const User = userModel
export const Token = tokenModel
export const Referral = referralModel
export const Kyc = kycModel
export const Mfa = mfaModel
