#!/bin/bash
 
# REMOVE any old version
sudo apt remove docker docker-engine docker.io containerd runc -y

# ENABLE HTTPS for APT
sudo apt update
sudo apt install ca-certificates curl gnupg lsb-release -y

#ADD docker PGP key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# ADD APT docker repository
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# INSTALL DOCKER
sudo apt update
sudo apt install docker-ce docker-ce-cli containerd.io -y

# INSTALL docker compose 1.27.4
sudo curl -L "https://github.com/docker/compose/releases/download/1.27.4/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Use docker compose as docker plugin (docker compose ps)
mkdir -p ~/.docker/cli-plugins
curl https://gist.githubusercontent.com/thaJeztah/b7950186212a49e91a806689e66b317d/raw/36d4c5854523502deed5b56842b0d34cd6ec0f70/docker-compose-plugin.sh > ~/.docker/cli-plugins/docker-compose 
chmod +x ~/.docker/cli-plugins/docker-compose

