export HYDRA_HOST=http://ip-172-31-18-36.eu-west-1.compute.internal:4445/oauth2/introspect
export NODE_REFERER=https://gringotts.pokmi.com
export APP_BASE_URL=/payWithPoken/api/v1
export PORT=3030
export HOSTNAME=0.0.0.0
export NODE_ENV=dev
export PSQL_USER=postgres_staging
export PSQL_PASSWORD=Ix2tWMLSw5mLhXUpEJ22ukzGM
export PSQL_HOST=database-1.cveuvcgxjlu8.eu-west-1.rds.amazonaws.com
export PSQL_DB=pay_with_poken_backend
export PSQL_PORT=5432
export NUM_CPUS=0
export BSC_PRIVATE_KEY_CONTRACT=3f55cc0f29590bea06350288128b0523d8aabcb136c1a9014a0a2012e21a9e9c
export ERC_PRIVATE_KEY_CONTRACT=3f55cc0f29590bea06350288128b0523d8aabcb136c1a9014a0a2012e21a9e9c
export COINMARKETAPIKEY=707f4522-3d18-4571-8e0a-7f9c630f2c62
export COINMARKETURIQUOTES=https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest

