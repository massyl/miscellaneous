export HYDRA_ADMIN_URL=http://ip-172-31-18-36.eu-west-1.compute.internal:4445
export MONGODB_URI=mongodb+srv://mypoken_wallet_staging:MeOjwUGAETuAAEyx@rpcluster.cmsvz.mongodb.net/service-api-staging
export DSN='postgres://postgres_staging:Ix2tWMLSw5mLhXUpEJ22ukzGM@database-1.cveuvcgxjlu8.eu-west-1.rds.amazonaws.com:5432/hydra?sslmode=disable&max_conns=20&max_idle_conns=4'
export URLS_SELF_ISSUER=https://1jb4erixdb.execute-api.eu-west-1.amazonaws.com/staging
export URLS_LOGIN=https://1jb4erixdb.execute-api.eu-west-1.amazonaws.com/staging/login
export URLS_CONSENT=https://1jb4erixdb.execute-api.eu-west-1.amazonaws.com/staging/consent
export URLS_LOGOUT=https://1jb4erixdb.execute-api.eu-west-1.amazonaws.com/staging/logout
export URLS_POST_LOGOUT_REDIRECT=http://oauth-client.localhost:8080/
export SECRETS_SYSTEM=youReallyNeedToChangeThis
export OIDC_SUBJECT_IDENTIFIERS_SUPPORTED_TYPES=pairwise
export OIDC_SUBJECT_IDENTIFIERS_PAIRWISE_SALT=youReallyNeedToChangeT
export LOG_LEAK_SENSITIVE_VALUES=true
export LOG_LEVEL=debug

