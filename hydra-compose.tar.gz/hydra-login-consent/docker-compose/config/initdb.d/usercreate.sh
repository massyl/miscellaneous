set -Eeuo pipefail

# Init shared DB and user for all modules
mongo --host 127.0.0.1:27017 -u "$MONGO_INITDB_ROOT_USERNAME" -p "$MONGO_INITDB_ROOT_PASSWORD" --authenticationDatabase "$MONGO_INITDB_DATABASE"  "$MONGO_INITDB_SHARED_DATABASE" <<EOF
    db.createUser({
        user: '$MONGO_INITDB_USERNAME',
        pwd: '$MONGO_INITDB_PASSWORD',
        roles: [ { role: 'readWrite', db: '$MONGO_INITDB_SHARED_DATABASE' } ]
    })
EOF
