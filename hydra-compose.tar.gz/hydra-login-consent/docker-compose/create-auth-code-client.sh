#!/bin/bash

cd $(dirname -- "$0")

docker compose \
	-f hydra.yml \
	exec hydra \
	hydra clients create \
	--endpoint http://hydra:4445 \
	--id hydra-auth-code-client-3 \
	--token-endpoint-auth-method none \
	--grant-types authorization_code \
	--response-types code \
	--audience http://resource1:8081/ \
	--scope openid,pokens,profile.read \
	--callbacks http://localhost:8080/auth \
	--post-logout-callbacks http://localhost:8080/auth \
	--allowed-cors-origins "http://172.17.0.1:3000"\
        --subject-type pairwise \
